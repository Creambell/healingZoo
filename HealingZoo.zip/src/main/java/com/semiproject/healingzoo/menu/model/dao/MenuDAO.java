package com.semiproject.healingzoo.menu.model.dao;

import java.util.ArrayList;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.semiproject.healingzoo.board.model.vo.Board;
import com.semiproject.healingzoo.board.model.vo.PageInfo;

@Repository
public class MenuDAO {

	public ArrayList<Board> selectFAQ(SqlSession sqlSession) {
		return (ArrayList)sqlSession.selectList("boardMapper.selectFAQ");
	}

}
