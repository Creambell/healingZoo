package com.semiproject.healingzoo.menu.model.service;

import java.util.ArrayList;
import java.util.Map;

import com.semiproject.healingzoo.board.model.vo.Board;

public interface MenuService {

	ArrayList<Board> selectFAQ();

	
	
	
}
